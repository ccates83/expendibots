"""
All constants that are used in the directory are stored here for organization
"""
# Board Constants
BOARD_SIDE_LENGTH = 8
BOARD_WIDTH = BOARD_SIDE_LENGTH
BOARD_HEIGHT = BOARD_SIDE_LENGTH
